
import React, { useState, useCallback, useRef } from 'react';
import { 
  Upload, 
  Trash2, 
  Play, 
  Pause, 
  BookOpen, 
  Settings2, 
  Loader2, 
  ChevronRight, 
  ChevronLeft,
  Volume2,
  Globe,
  Sparkles,
  Camera,
  Mic2,
  Film
} from 'lucide-react';
import { Genre, Tone, POV, Audience, StoryLength, Language, StoryConfig, UploadedImage, GeneratedStory } from './types';
import { generateStoryFromImages, narrateText, decodeAudioData } from './geminiService';

const INITIAL_CONFIG: StoryConfig = {
  genre: Genre.Adventure,
  tone: Tone.Cinematic,
  pov: POV.ThirdPerson,
  audience: Audience.Teens,
  length: StoryLength.Medium,
  language: Language.English
};

const StorytellerCameraIcon = ({ className }: { className?: string }) => (
  <svg 
    viewBox="0 0 100 100" 
    className={className}
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <defs>
      <linearGradient id="iconGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#60A5FA" />
        <stop offset="100%" stopColor="#A855F7" />
      </linearGradient>
      <filter id="glowEffect">
        <feGaussianBlur stdDeviation="1.5" result="blur"/>
        <feMerge>
          <feMergeNode in="blur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>
    
    {/* Stylized Human Silhouette Profile */}
    <path 
      d="M35 85 C35 70, 40 60, 50 60 C60 60, 65 70, 65 85" 
      stroke="url(#iconGrad)" 
      strokeWidth="3" 
      strokeLinecap="round" 
    />
    <circle cx="50" cy="45" r="12" stroke="url(#iconGrad)" strokeWidth="3" fill="transparent" />
    
    {/* Camera Element held by the figure */}
    <rect x="58" y="42" width="18" height="12" rx="2" fill="url(#iconGrad)" opacity="0.9" />
    <circle cx="78" cy="48" r="5" stroke="url(#iconGrad)" strokeWidth="2" fill="#0f172a" />
    <circle cx="78" cy="48" r="2" fill="url(#iconGrad)" />
    
    {/* Narrative Waves / Speaking Lines */}
    <path 
      className="animate-pulse" 
      d="M85 35 Q95 48 85 61" 
      stroke="#60A5FA" 
      strokeWidth="2" 
      strokeLinecap="round" 
      filter="url(#glowEffect)"
    />
    <path 
      className="animate-pulse" 
      style={{ animationDelay: '0.2s' }}
      d="M90 30 Q105 48 90 66" 
      stroke="#A855F7" 
      strokeWidth="1.5" 
      strokeLinecap="round" 
      opacity="0.6"
    />
    
    {/* Lens Flare / Sparkle */}
    <path 
      d="M78 40 L78 30 M73 35 L83 35" 
      stroke="#60A5FA" 
      strokeWidth="1" 
      strokeLinecap="round" 
    />
  </svg>
);

const Logo = () => (
  <div className="flex flex-col items-center mb-12 group cursor-default">
    <div className="relative mb-6">
      {/* Dynamic Background Aura */}
      <div className="absolute inset-0 bg-blue-600/20 blur-[60px] rounded-full scale-150 group-hover:bg-purple-600/30 transition-all duration-1000"></div>
      
      {/* Icon Frame */}
      <div className="relative flex items-center justify-center w-32 h-32 bg-slate-900/90 border border-slate-700/50 rounded-[2.5rem] transition-all duration-700 shadow-2xl backdrop-blur-2xl group-hover:border-blue-500/40 group-hover:rotate-2 group-hover:scale-105">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-600/10 rounded-[2.5rem]"></div>
        
        <StorytellerCameraIcon className="w-24 h-24" />
        
        {/* Cinematic Labels - Removed REC per user request */}
        <div className="absolute bottom-4 -right-2 bg-slate-800 p-1.5 rounded-lg border border-slate-700 shadow-xl group-hover:translate-x-1 transition-transform">
          <Mic2 className="text-purple-400" size={14} />
        </div>
      </div>
    </div>

    <div className="flex flex-col items-center text-center">
      <h1 className="text-5xl md:text-7xl font-serif font-bold tracking-tight">
        <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-100 via-blue-400 to-indigo-200">Visionary</span>
        <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-300 via-purple-400 to-pink-300 ml-3">Tales</span>
      </h1>
      <div className="mt-4 flex items-center gap-4">
        <div className="h-[2px] w-12 bg-gradient-to-r from-transparent to-blue-500/50"></div>
        <p className="text-[10px] uppercase tracking-[0.6em] font-black text-slate-500">Capture • Narrate • Imagine</p>
        <div className="h-[2px] w-12 bg-gradient-to-l from-transparent to-purple-500/50"></div>
      </div>
    </div>
  </div>
);

export default function App() {
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [config, setConfig] = useState<StoryConfig>(INITIAL_CONFIG);
  const [isGenerating, setIsGenerating] = useState(false);
  const [story, setStory] = useState<GeneratedStory | null>(null);
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [isNarrating, setIsNarrating] = useState(false);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    files.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImages(prev => [
          ...prev,
          {
            id: crypto.randomUUID(),
            url: URL.createObjectURL(file),
            base64: reader.result as string,
            mimeType: file.type
          }
        ]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (id: string) => {
    setImages(prev => prev.filter(img => img.id !== id));
  };

  const generateStory = async () => {
    if (images.length === 0) return;
    setIsGenerating(true);
    try {
      const generated = await generateStoryFromImages(images, config);
      setStory(generated);
      setCurrentSectionIndex(0);
    } catch (error) {
      console.error("Story generation failed:", error);
      alert("Something went wrong generating your story.");
    } finally {
      setIsGenerating(false);
    }
  };

  const stopNarration = useCallback(() => {
    if (audioSourceRef.current) {
      audioSourceRef.current.stop();
      audioSourceRef.current = null;
    }
    setIsNarrating(false);
  }, []);

  const playNarration = async () => {
    if (!story) return;
    if (isNarrating) {
      stopNarration();
      return;
    }

    setIsNarrating(true);
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({
          sampleRate: 24000
        });
      }
      
      const textToNarrate = story.sections[currentSectionIndex].content;
      const audioBufferRaw = await narrateText(textToNarrate);
      const audioBuffer = await decodeAudioData(new Uint8Array(audioBufferRaw), audioContextRef.current);
      
      const source = audioContextRef.current.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContextRef.current.destination);
      source.onended = () => setIsNarrating(false);
      
      audioSourceRef.current = source;
      source.start();
    } catch (error) {
      console.error("Narration failed:", error);
      setIsNarrating(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-start p-4 md:p-8 max-w-6xl mx-auto">
      <header className="w-full text-center">
        <Logo />
        {!story && (
          <p className="text-slate-400 max-w-xl mx-auto mb-12 font-medium leading-relaxed">
            Turn your visual gallery into a high-definition narrated experience. Choose your settings and let the lens speak.
          </p>
        )}
      </header>

      {!story ? (
        <main className="w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-in fade-in duration-1000">
          {/* Controls Section */}
          <div className="lg:col-span-4 space-y-6 order-2 lg:order-1">
            <div className="bg-slate-800/40 p-6 rounded-[2.5rem] border border-slate-700/50 shadow-2xl backdrop-blur-md">
              <div className="flex items-center gap-2 mb-6 text-blue-400 border-b border-slate-700/50 pb-4">
                <Settings2 size={20} strokeWidth={2.5} />
                <h2 className="font-bold uppercase tracking-[0.2em] text-[11px]">Configuration</h2>
              </div>
              
              <div className="space-y-4">
                <OptionSelect 
                  label="Language" 
                  value={config.language} 
                  options={Object.values(Language)} 
                  onChange={(v) => setConfig({...config, language: v as Language})} 
                  icon={<Globe size={14} className="text-blue-400" />}
                />
                <OptionSelect 
                  label="Genre" 
                  value={config.genre} 
                  options={Object.values(Genre)} 
                  onChange={(v) => setConfig({...config, genre: v as Genre})} 
                />
                <OptionSelect 
                  label="Tone" 
                  value={config.tone} 
                  options={Object.values(Tone)} 
                  onChange={(v) => setConfig({...config, tone: v as Tone})} 
                />
                <OptionSelect 
                  label="Point of View" 
                  value={config.pov} 
                  options={Object.values(POV)} 
                  onChange={(v) => setConfig({...config, pov: v as POV})} 
                />
                <OptionSelect 
                  label="Audience" 
                  value={config.audience} 
                  options={Object.values(Audience)} 
                  onChange={(v) => setConfig({...config, audience: v as Audience})} 
                />
                <OptionSelect 
                  label="Length" 
                  value={config.length} 
                  options={Object.values(StoryLength)} 
                  onChange={(v) => setConfig({...config, length: v as StoryLength})} 
                />
              </div>

              <button
                disabled={images.length === 0 || isGenerating}
                onClick={generateStory}
                className={`w-full mt-10 py-5 rounded-3xl font-black text-xs uppercase tracking-[0.3em] flex items-center justify-center gap-3 transition-all shadow-2xl shadow-blue-900/20 ${
                  images.length === 0 || isGenerating
                    ? 'bg-slate-800 text-slate-600 cursor-not-allowed border border-slate-700'
                    : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:scale-[1.02] text-white active:scale-95 border border-white/10'
                }`}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="animate-spin" size={18} />
                    Inking Narrative...
                  </>
                ) : (
                  <>
                    <Film size={18} />
                    Start Directing
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Image Upload Area */}
          <div className="lg:col-span-8 order-1 lg:order-2">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-5">
              {images.map((img, idx) => (
                <div key={img.id} className="relative group aspect-[4/5] rounded-[2rem] overflow-hidden border border-slate-700/50 hover:border-blue-500/50 transition-all shadow-2xl hover:shadow-blue-900/20">
                  <img src={img.url} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={`Upload ${idx}`} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button 
                      onClick={() => removeImage(img.id)}
                      className="p-3 bg-red-500/90 text-white rounded-2xl hover:bg-red-600 transition-colors shadow-xl backdrop-blur-md"
                    >
                      <Trash2 size={24} />
                    </button>
                  </div>
                  <div className="absolute bottom-4 left-4 bg-white/10 backdrop-blur-xl px-3 py-1 rounded-xl text-[10px] font-black tracking-widest border border-white/20 text-white">
                    CHAPTER {idx + 1}
                  </div>
                </div>
              ))}
              
              <label className="aspect-[4/5] flex flex-col items-center justify-center border-2 border-dashed border-slate-700/50 rounded-[2rem] cursor-pointer hover:bg-slate-800/30 hover:border-blue-500/50 transition-all group">
                <div className="w-16 h-16 rounded-[1.5rem] bg-slate-800 flex items-center justify-center group-hover:scale-110 group-hover:bg-blue-900/20 transition-all mb-4">
                  <Camera className="text-slate-500 group-hover:text-blue-400" size={32} strokeWidth={1.5} />
                </div>
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 group-hover:text-blue-300">Import Scene</span>
                <input 
                  type="file" 
                  multiple 
                  accept="image/*" 
                  className="hidden" 
                  onChange={handleImageUpload} 
                />
              </label>
            </div>
            {images.length === 0 && (
              <div className="mt-8 p-16 text-center bg-slate-800/10 border border-slate-800/30 rounded-[3rem] border-dashed">
                <p className="text-slate-500 italic font-serif text-lg">"Capture the vision, craft the voice."</p>
                <p className="text-slate-600 text-xs mt-3 uppercase tracking-[0.3em] font-bold">Import your visuals to begin the narration</p>
              </div>
            )}
          </div>
        </main>
      ) : (
        /* Story Viewer */
        <main className="w-full animate-in zoom-in-95 fade-in duration-700">
          <div className="flex flex-col items-center">
            <button 
              onClick={() => {
                setStory(null);
                stopNarration();
              }}
              className="mb-10 text-slate-500 hover:text-white flex items-center gap-2 transition-all font-bold text-xs uppercase tracking-widest group"
            >
              <div className="p-2 rounded-full bg-slate-800 group-hover:bg-slate-700">
                <ChevronLeft size={16} />
              </div>
              Return to Studio
            </button>

            <div className="w-full bg-slate-900/80 border border-slate-800/50 rounded-[3rem] overflow-hidden shadow-[0_32px_64px_-16px_rgba(0,0,0,0.6)] backdrop-blur-2xl relative">
              <div className="grid grid-cols-1 md:grid-cols-2 h-full min-h-[650px]">
                {/* Visual Side */}
                <div className="bg-black/40 flex items-center justify-center p-6 md:p-12 border-r border-slate-800/30">
                   <div className="relative group overflow-hidden rounded-[2.5rem] shadow-2xl w-full">
                    <img 
                      src={images[story.sections[currentSectionIndex].imageIndex].url} 
                      className="max-h-[75vh] w-full object-contain rounded-[2.5rem]"
                      alt="Scene"
                    />
                    <div className="absolute inset-0 ring-1 ring-inset ring-white/10 rounded-[2.5rem]"></div>
                   </div>
                </div>

                {/* Story Side */}
                <div className="p-10 md:p-16 flex flex-col justify-between bg-slate-900/20">
                  <div>
                    <div className="flex items-center gap-4 mb-10">
                      <div className="px-5 py-2 bg-blue-500/10 border border-blue-500/20 rounded-full text-[11px] font-black uppercase tracking-[0.2em] text-blue-400">
                        Frame {currentSectionIndex + 1}
                      </div>
                      <div className="h-px flex-1 bg-slate-800/50"></div>
                    </div>
                    
                    <h1 className="text-4xl md:text-5xl font-serif font-bold mb-12 text-white leading-[1.1] bg-clip-text text-transparent bg-gradient-to-br from-white via-white to-slate-400">
                      {story.title}
                    </h1>
                    
                    <div className="relative">
                      <p className="text-xl md:text-2xl text-slate-200 leading-[1.6] font-light italic font-serif">
                        {story.sections[currentSectionIndex].content}
                      </p>
                    </div>
                  </div>

                  <div className="mt-12 flex flex-wrap items-center justify-between gap-8 pt-10 border-t border-slate-800/50">
                    <div className="flex items-center gap-6">
                      <button 
                        onClick={playNarration}
                        className={`p-7 rounded-[2.5rem] flex items-center justify-center transition-all shadow-2xl ${
                          isNarrating 
                          ? 'bg-blue-600 text-white animate-pulse shadow-blue-500/30' 
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white shadow-black/50 hover:scale-105'
                        }`}
                      >
                        {isNarrating ? <Pause size={36} strokeWidth={1.5} /> : <Volume2 size={36} strokeWidth={1.5} />}
                      </button>
                      <div className="hidden sm:block">
                        <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em] mb-1">Voice Processing</p>
                        <p className="text-sm font-medium text-slate-400">{isNarrating ? 'Broadcasting...' : 'Ready for playback'}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <button 
                        disabled={currentSectionIndex === 0}
                        onClick={() => {
                          stopNarration();
                          setCurrentSectionIndex(prev => prev - 1);
                        }}
                        className="p-6 bg-slate-800/60 backdrop-blur-md border border-slate-700/50 rounded-[2rem] disabled:opacity-20 hover:bg-slate-800 text-white transition-all active:scale-95 shadow-lg"
                      >
                        <ChevronLeft size={32} />
                      </button>
                      <button 
                        disabled={currentSectionIndex === story.sections.length - 1}
                        onClick={() => {
                          stopNarration();
                          setCurrentSectionIndex(prev => prev + 1);
                        }}
                        className="p-6 bg-slate-800/60 backdrop-blur-md border border-slate-700/50 rounded-[2rem] disabled:opacity-20 hover:bg-slate-800 text-white transition-all active:scale-95 shadow-lg"
                      >
                        <ChevronRight size={32} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      )}

      <footer className="w-full mt-32 py-12 border-t border-slate-800/30 text-center">
        <div className="flex items-center justify-center gap-8 mb-8 opacity-25">
           <StorytellerCameraIcon className="w-10 h-10" />
           <div className="h-6 w-px bg-slate-700"></div>
           <Camera size={22} />
           <div className="h-6 w-px bg-slate-700"></div>
           <Mic2 size={22} />
        </div>
        <p className="text-slate-600 text-[10px] font-black uppercase tracking-[0.5em]">
          Visionary Studio • Gemini Multimodal Narrator • 2025
        </p>
      </footer>
    </div>
  );
}

function OptionSelect({ label, value, options, onChange, icon }: { 
  label: string; 
  value: string; 
  options: string[]; 
  onChange: (val: string) => void;
  icon?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-2 ml-1">
        {icon || <div className="w-3 h-3 rounded-full bg-slate-700"></div>}
        <label className="text-[10px] uppercase font-black text-slate-500 tracking-[0.2em]">{label}</label>
      </div>
      <div className="relative">
        <select 
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="bg-slate-900/60 border border-slate-700/50 text-slate-300 text-sm rounded-2xl block w-full p-4 outline-none focus:ring-1 focus:ring-blue-500/40 focus:border-blue-500/40 transition-all appearance-none cursor-pointer font-medium hover:bg-slate-800/60"
          style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%23475569'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E")`, backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1.25rem center', backgroundSize: '0.9rem' }}
        >
          {options.map(opt => (
            <option key={opt} value={opt} className="bg-slate-900">{opt}</option>
          ))}
        </select>
      </div>
    </div>
  );
}
