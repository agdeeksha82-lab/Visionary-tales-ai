
export enum Genre {
  Fantasy = 'Fantasy',
  Mystery = 'Mystery',
  SciFi = 'Sci-Fi',
  Horror = 'Horror',
  Romance = 'Romance',
  Childrens = "Children's Story",
  Adventure = 'Adventure'
}

export enum Tone {
  Whimsical = 'Whimsical',
  Dark = 'Dark',
  Emotional = 'Emotional',
  Cinematic = 'Cinematic',
  Lighthearted = 'Lighthearted'
}

export enum POV {
  FirstPerson = 'First Person',
  ThirdPerson = 'Third Person'
}

export enum Audience {
  Kids = 'Kids',
  Teens = 'Teens',
  Adults = 'Adults'
}

export enum StoryLength {
  Short = 'Short',
  Medium = 'Medium',
  Long = 'Long'
}

export enum Language {
  English = 'English',
  Kannada = 'Kannada',
  Hindi = 'Hindi'
}

export interface StoryConfig {
  genre: Genre;
  tone: Tone;
  pov: POV;
  audience: Audience;
  length: StoryLength;
  language: Language;
}

export interface StorySection {
  imageIndex: number;
  content: string;
}

export interface GeneratedStory {
  title: string;
  sections: StorySection[];
}

export interface UploadedImage {
  id: string;
  url: string;
  base64: string;
  mimeType: string;
}
