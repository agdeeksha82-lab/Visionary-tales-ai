
import { GoogleGenAI, Type, GenerateContentResponse, Modality } from "@google/genai";
import { StoryConfig, GeneratedStory, UploadedImage } from "./types";

// Always use named parameter and process.env.API_KEY directly.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateStoryFromImages(
  images: UploadedImage[],
  config: StoryConfig
): Promise<GeneratedStory> {
  const imageParts = images.map(img => ({
    inlineData: {
      data: img.base64.split(',')[1],
      mimeType: img.mimeType
    }
  }));

  const prompt = `
    You are a professional visual storyteller. Analyze the uploaded images and create a coherent story.
    
    Each image represents one scene in the story.
    Maintain character consistency across images.
    
    CRITICAL: The story MUST be written entirely in ${config.language}.
    
    Configuration:
    - Language: ${config.language}
    - Genre: ${config.genre}
    - Tone: ${config.tone}
    - Point of View: ${config.pov}
    - Audience: ${config.audience}
    - Story Length: ${config.length}
    
    Output Format (JSON):
    {
      "title": "Story Title in ${config.language}",
      "sections": [
        {
          "imageIndex": 0,
          "content": "Narrative for image 1 in ${config.language}..."
        },
        ...
      ]
    }
    
    Narrative Rules:
    - No technical descriptions of the images.
    - Immersive storytelling only.
    - Smooth transitions between sections.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        ...imageParts,
        { text: prompt }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          sections: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                imageIndex: { type: Type.NUMBER },
                content: { type: Type.STRING }
              },
              required: ["imageIndex", "content"]
            }
          }
        },
        required: ["title", "sections"]
      }
    }
  });

  // Access the .text property directly and handle potential undefined.
  const text = response.text || '';
  return JSON.parse(text) as GeneratedStory;
}

export async function narrateText(text: string, voice: string = 'Kore'): Promise<ArrayBuffer> {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: voice },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) {
    throw new Error("Failed to generate narration audio.");
  }

  return decode(base64Audio).buffer;
}

// Audio Utils - Manually implemented as per guidelines.
export function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Manually implemented raw PCM decoding as per guidelines.
export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
